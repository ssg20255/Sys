# app/forms.py - WTForms definitions for authentication and order creation
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, SelectField, FieldList, FormField, IntegerField, FloatField, TextAreaField, DateField
from wtforms.validators import DataRequired, Email, Optional

class LoginForm(FlaskForm):
    email = StringField("Email", validators=[DataRequired(), Email()])
    password = PasswordField("Password", validators=[DataRequired()])
    submit = SubmitField("Login")

class ItemForm(FlaskForm):
    material = StringField("Material", validators=[DataRequired()])
    quantity = FloatField("Quantity", validators=[DataRequired()])
    unit = StringField("Unit", validators=[Optional()])
    supplier = StringField("Supplier", validators=[Optional()])
    delivery_date = DateField("Delivery Date", validators=[Optional()], format='%Y-%m-%d')
    payment_terms = StringField("Payment Terms", validators=[Optional()])
    import_license = StringField("Import License", validators=[Optional()])
    notes = TextAreaField("Notes", validators=[Optional()])

class OrderForm(FlaskForm):
    customer_name = SelectField("Customer", validators=[DataRequired()], choices=[])
    order_number = StringField("Order Number", validators=[Optional()])
    items = FieldList(FormField(ItemForm), min_entries=1, max_entries=50)
    internal_notes = TextAreaField("Internal Notes", validators=[Optional()])
    submit = SubmitField("Submit Order")