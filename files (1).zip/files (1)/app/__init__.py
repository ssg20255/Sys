# app/__init__.py - create Flask application and initialize extensions
import os
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_migrate import Migrate
from flask_mail import Mail
from flask_babel import Babel
from dotenv import load_dotenv

load_dotenv()

db = SQLAlchemy()
migrate = Migrate()
login_manager = LoginManager()
mail = Mail()
babel = Babel()

def create_app():
    app = Flask(__name__, static_folder="static", template_folder="templates")
    # Basic configuration with fallbacks
    app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'dev-secret-key')
    # Database: default sqlite but allow DATABASE_URL env
    database_url = os.getenv('DATABASE_URL', f"sqlite:///{os.path.join(app.root_path, '..', 'data.sqlite')}")
    app.config['SQLALCHEMY_DATABASE_URI'] = database_url
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    # Mail config with safe defaults (console fallback)
    app.config['MAIL_SERVER'] = os.getenv('MAIL_SERVER', '')
    app.config['MAIL_PORT'] = int(os.getenv('MAIL_PORT', '0') or 0)
    app.config['MAIL_USERNAME'] = os.getenv('MAIL_USERNAME', '')
    app.config['MAIL_PASSWORD'] = os.getenv('MAIL_PASSWORD', '')
    app.config['MAIL_USE_TLS'] = os.getenv('MAIL_USE_TLS', 'False') == 'True'
    app.config['MAIL_USE_SSL'] = os.getenv('MAIL_USE_SSL', 'False') == 'True'
    app.config['MAIL_DEFAULT_SENDER'] = os.getenv('MAIL_DEFAULT_SENDER', 'noreply@example.com')

    # Babel (i18n)
    app.config['BABEL_DEFAULT_LOCALE'] = os.getenv('BABEL_DEFAULT_LOCALE', 'en')
    app.config['BABEL_SUPPORTED_LOCALES'] = ['en', 'ar']

    # Telegram
    app.config['TELEGRAM_BOT_TOKEN'] = os.getenv('TELEGRAM_BOT_TOKEN', '')
    app.config['TELEGRAM_CHAT_ID'] = os.getenv('TELEGRAM_CHAT_ID', '')

    db.init_app(app)
    migrate.init_app(app, db)
    login_manager.init_app(app)
    mail.init_app(app)
    babel.init_app(app)

    # Register blueprints / views
    from .views import main_bp
    app.register_blueprint(main_bp)

    # Create log directory
    logs_dir = os.path.join(app.root_path, '..', 'app_logs')
    os.makedirs(logs_dir, exist_ok=True)

    return app