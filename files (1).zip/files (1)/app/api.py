# app/api.py - simple API endpoints for fetching order and version partials
from flask import Blueprint, render_template
from .models import Order, OrderVersion
api_bp = Blueprint('api', __name__, url_prefix='/api')

@api_bp.route('/order/<int:order_id>')
def get_order_modal(order_id):
    order = Order.query.get_or_404(order_id)
    return render_template('order_modal.html', order=order)

@api_bp.route('/version/<int:version_id>')
def get_version_snapshot(version_id):
    v = OrderVersion.query.get_or_404(version_id)
    data = {}
    try:
        import json
        data = json.loads(v.snapshot)
    except Exception:
        data = {"error":"invalid snapshot"}
    return render_template('version_snapshot.html', version=v, data=data)