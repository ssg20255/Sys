// app/static/js/main.js - global scripts (kept minimal)
console.log("OMS app loaded");

// Simple global error handling to provide graceful fallbacks
window.addEventListener('error', function(e){
  console.error("Global error captured:", e.error || e.message);
  // Show non-intrusive notification
  const b = document.createElement('div');
  b.className = 'alert alert-warning';
  b.style.position = 'fixed'; b.style.bottom='10px'; b.style.right='10px'; b.style.zIndex='9999';
  b.textContent = 'An error occurred. Functionality may be degraded.';
  document.body.appendChild(b);
  setTimeout(()=> b.remove(), 10000);
});