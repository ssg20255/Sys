# app/utils.py - helpers for PDF, Excel, notifications with robust fallbacks
import os
import io
import csv
import json
import traceback
from flask import current_app, render_template, make_response
from datetime import datetime

# PDF generation: try multiple backends
def generate_pdf_from_template(template_name, context, filename="document.pdf"):
    html = render_template(template_name, **context)
    # Try WeasyPrint
    try:
        from weasyprint import HTML, CSS
        css_path = os.path.join(current_app.static_folder, 'css', 'pdf.css')
        html_obj = HTML(string=html, base_url=current_app.root_path)
        pdf = html_obj.write_pdf(stylesheets=[CSS(css_path)]) if os.path.exists(css_path) else html_obj.write_pdf()
        response = make_response(pdf)
        response.headers['Content-Type'] = 'application/pdf'
        response.headers['Content-Disposition'] = f'attachment; filename={filename}'
        return response
    except Exception as e:
        current_app.logger.warning("WeasyPrint not available or failed: %s", e)

    # Fallback: xhtml2pdf (pisa)
    try:
        from xhtml2pdf import pisa
        result = io.BytesIO()
        pisa_status = pisa.CreatePDF(io.StringIO(html), dest=result)
        if pisa_status.err:
            raise Exception("xhtml2pdf failed")
        result.seek(0)
        response = make_response(result.read())
        response.headers['Content-Type'] = 'application/pdf'
        response.headers['Content-Disposition'] = f'attachment; filename={filename}'
        return response
    except Exception as e:
        current_app.logger.warning("xhtml2pdf not available or failed: %s", e)

    # Final fallback: return HTML as attachment
    response = make_response(html)
    response.headers['Content-Type'] = 'text/html'
    response.headers['Content-Disposition'] = f'attachment; filename={filename.replace(".pdf", ".html")}'
    return response

# Excel export (DataFrame preferred)
def generate_excel_from_orders(orders, filename="orders.xlsx"):
    # orders: list of dicts
    try:
        import pandas as pd
        df = pd.DataFrame(orders)
        output = io.BytesIO()
        # Prefer openpyxl/xlsxwriter, pandas chooses automatically
        df.to_excel(output, index=False)
        output.seek(0)
        response = make_response(output.read())
        response.headers['Content-Type'] = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        response.headers['Content-Disposition'] = f'attachment; filename={filename}'
        return response
    except Exception as e:
        current_app.logger.warning("Pandas/openpyxl missing or failed: %s", e)

    # Fallback: CSV
    try:
        output = io.StringIO()
        if orders:
            writer = csv.DictWriter(output, fieldnames=orders[0].keys())
            writer.writeheader()
            for o in orders:
                writer.writerow({k: (v if isinstance(v, (str, int, float)) else str(v)) for k,v in o.items()})
        else:
            output.write("")
        response = make_response(output.getvalue())
        response.headers['Content-Type'] = 'text/csv'
        response.headers['Content-Disposition'] = f'attachment; filename={filename.replace(".xlsx",".csv")}'
        return response
    except Exception as e:
        current_app.logger.error("CSV fallback failed: %s", e)
        return make_response("Failed to generate export", 500)

# Notifications: email and telegram with DB logging
def send_notification(user_email, notif_type, subject, body, channel='email', html=None, extra_payload=None):
    from . import mail, db
    from .models import NotificationLog
    import requests
    app = current_app._get_current_object()
    payload = extra_payload or {}
    log = NotificationLog(user_email=user_email, channel=channel, notif_type=notif_type, payload=str(payload))
    try:
        if channel == 'email':
            # Try sending email
            try:
                from flask_mail import Message
                msg = Message(subject=subject, recipients=[user_email])
                msg.body = body
                if html:
                    msg.html = html
                mail.send(msg)
                log.success = True
            except Exception as e:
                app.logger.warning("Email sending failed; falling back to console log: %s", e)
                app.logger.info("Email to %s: Subject: %s Body: %s", user_email, subject, body)
                log.error = str(e)
                log.success = False

        elif channel == 'telegram':
            token = app.config.get('TELEGRAM_BOT_TOKEN')
            chat_id = app.config.get('TELEGRAM_CHAT_ID')
            if not token or not chat_id:
                raise Exception("Telegram not configured")
            text = f"{subject}\n\n{body}"
            url = f"https://api.telegram.org/bot{token}/sendMessage"
            resp = requests.post(url, data={"chat_id": chat_id, "text": text})
            if resp.status_code != 200:
                raise Exception(f"Telegram API error: {resp.status_code} {resp.text}")
            log.success = True
        else:
            raise Exception("Unknown channel")
    except Exception as e:
        log.error = str(e) + "\n" + traceback.format_exc()
        app.logger.error("Notification failed: %s", e)
        log.success = False
    finally:
        db.session.add(log)
        db.session.commit()
    return log.success