# app/config.py - simple central config constants
ORDER_STATUSES = ['draft', 'submitted', 'approved', 'rejected', 'shipped', 'delivered', 'cancelled']
DEFAULT_ITEMS_LIMIT = 100