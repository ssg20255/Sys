# app/views.py - main views and API endpoints
import json
from flask import Blueprint, render_template, request, redirect, url_for, flash, current_app, jsonify
from .forms import LoginForm, OrderForm
from .models import User, Role, Order, OrderItem, Draft, OrderVersion
from . import db, login_manager
from werkzeug.security import check_password_hash
from datetime import datetime
from .utils import generate_pdf_from_template, generate_excel_from_orders, send_notification
from functools import wraps

main_bp = Blueprint('main', __name__)

# Simple user loader and auth (for demonstration)
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# role_required decorator
def role_required(*roles):
    def decorator(f):
        @wraps(f)
        def wrapped(*args, **kwargs):
            from flask_login import current_user, login_required
            if not current_user.is_authenticated:
                return redirect(url_for('main.login'))
            if any(current_user.has_role(r) for r in roles) or current_user.has_role('admin'):
                return f(*args, **kwargs)
            flash("Insufficient permissions", "warning")
            return redirect(url_for('main.dashboard'))
        return wrapped
    return decorator

@main_bp.route('/')
def index():
    return redirect(url_for('main.dashboard'))

@main_bp.route('/login', methods=['GET', 'POST'])
def login():
    from flask_login import login_user
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user and check_password_hash(user.password_hash, form.password.data):
            login_user(user)
            flash("Logged in", "success")
            return redirect(url_for('main.dashboard'))
        else:
            flash("Invalid credentials", "danger")
    return render_template('login.html', form=form)

@main_bp.route('/logout')
def logout():
    from flask_login import logout_user
    logout_user()
    flash("Logged out", "info")
    return redirect(url_for('main.login'))

@main_bp.route('/dashboard')
def dashboard():
    # Filters
    q = request.args.get('q', '').strip()
    customer = request.args.get('customer', '').strip()
    status = request.args.get('status', '').strip()
    order_number = request.args.get('order_number', '').strip()

    query = Order.query
    # Only approved orders visible to customers; for other roles show according to role
    from flask_login import current_user
    if current_user.is_authenticated and current_user.has_role('customer'):
        query = query.filter_by(customer_name=current_user.name)
    else:
        # show approved and submitted and other statuses to appropriate roles
        pass

    if q:
        query = query.filter(Order.customer_name.ilike(f"%{q}%") | Order.order_number.ilike(f"%{q}%"))
    if customer:
        query = query.filter_by(customer_name=customer)
    if status:
        query = query.filter_by(status=status)
    if order_number:
        query = query.filter_by(order_number=order_number)

    orders = query.order_by(Order.created_at.desc()).limit(200).all()
    # Convert to simple dicts for frontend
    return render_template('dashboard.html', orders=orders, filters=dict(q=q, customer=customer, status=status, order_number=order_number))

@main_bp.route('/order/new', methods=['GET', 'POST'])
@role_required('cse', 'pe')
def order_new():
    # Multi-step handled client-side; server accepts full JSON via autosave and submit
    if request.method == 'POST':
        data = request.get_json() or {}
        # Create order
        order_number = data.get('order_number') or f"ORD-{int(datetime.utcnow().timestamp())}"
        order = Order(order_number=order_number, customer_name=data.get('customer_name', ''), status=data.get('status','draft'), created_by_email=data.get('created_by'))
        items = data.get('items', [])
        for it in items:
            item = OrderItem(
                material=it.get('material'),
                quantity=it.get('quantity'),
                unit=it.get('unit'),
                supplier=it.get('supplier'),
                payment_terms=it.get('payment_terms'),
                import_license=it.get('import_license'),
                notes=it.get('notes')
            )
            order.items.append(item)
        db.session.add(order)
        db.session.commit()
        # create first version
        v = OrderVersion(order_id=order.id, user_email=data.get('created_by'), snapshot=json.dumps(data))
        db.session.add(v)
        db.session.commit()
        # send notification to management about submitted order (attempt)
        try:
            send_notification(user_email=current_app.config.get('MAIL_DEFAULT_SENDER'), notif_type='order_submitted', subject=f"Order submitted {order.order_number}", body=f"Order {order.order_number} submitted by {data.get('created_by')}", channel='email')
        except Exception:
            current_app.logger.exception("Notification failed")
        return jsonify({"status":"ok", "order_id": order.id, "order_number": order.order_number}), 201

    # GET: render order form app (single-page multi-step handled client js)
    return render_template('order_form.html')

@main_bp.route('/order/autosave', methods=['POST'])
def order_autosave():
    # Accept draft JSON and save per user
    data = request.get_json() or {}
    user_email = data.get('created_by') or request.form.get('created_by')
    if not user_email:
        return jsonify({"error":"missing user email"}), 400
    content = json.dumps(data)
    draft = Draft.query.filter_by(user_email=user_email).first()
    if not draft:
        draft = Draft(user_email=user_email, content=content)
        db.session.add(draft)
    else:
        draft.content = content
    db.session.commit()
    # Save version snapshot if order exists
    order_id = data.get('order_id')
    if order_id:
        v = OrderVersion(order_id=order_id, user_email=user_email, snapshot=content)
        db.session.add(v)
        db.session.commit()
    return jsonify({"status":"saved", "updated_at": draft.updated_at.isoformat()}), 200

@main_bp.route('/drafts')
def list_drafts():
    from flask_login import current_user
    if not current_user.is_authenticated:
        return jsonify([])
    drafts = Draft.query.filter((Draft.user_email==current_user.email) | (Draft.user_email!=None)).order_by(Draft.updated_at.desc()).all()
    # Only allow admin to see all
    if not current_user.has_role('admin'):
        drafts = [d for d in drafts if d.user_email==current_user.email]
    return jsonify([{"user_email":d.user_email, "content": json.loads(d.content), "updated_at":d.updated_at.isoformat()} for d in drafts])

@main_bp.route('/export/orders')
def export_orders():
    # Build filtered orders list similar to dashboard
    query = Order.query
    orders = []
    for o in query.limit(500).all():
        items_desc = "; ".join([f"{it.material}({it.quantity}{it.unit or ''})" for it in o.items])
        orders.append({
            "order_number": o.order_number,
            "customer_name": o.customer_name,
            "materials": items_desc,
            "quantity": sum([it.quantity or 0 for it in o.items]),
            "supplier": "; ".join(set([it.supplier or "" for it in o.items])),
            "delivery_date": o.delivery_date.isoformat() if o.delivery_date else "",
            "status": o.status
        })
    return generate_excel_from_orders(orders, filename="orders_export.xlsx")

@main_bp.route('/template/preview', methods=['POST'])
def template_preview():
    data = request.get_json() or {}
    template_type = data.get('template', 'price_offer')
    # Render partial preview HTML and return
    if template_type == 'price_offer':
        tpl = 'templates/price_offer_preview.html'
    elif template_type == 'inquiry':
        tpl = 'templates/inquiry_preview.html'
    else:
        tpl = 'templates/po_preview.html'
    # for simplicity use the same preview file path names under templates/
    return render_template(f"{template_type}_preview.html", data=data)

@main_bp.route('/template/export_pdf', methods=['POST'])
def template_export_pdf():
    data = request.get_json() or {}
    template_type = data.get('template', 'price_offer')
    template_map = {
        'price_offer': 'pdf_price_offer.html',
        'inquiry': 'pdf_inquiry.html',
        'po': 'pdf_po.html'
    }
    tpl = template_map.get(template_type, 'pdf_price_offer.html')
    return generate_pdf_from_template(tpl, {'data': data}, filename=f"{template_type}.pdf")

# Admin endpoints for version browsing & revert
@main_bp.route('/admin/versions')
@role_required('admin')
def admin_versions():
    versions = OrderVersion.query.order_by(OrderVersion.created_at.desc()).limit(200).all()
    return render_template('admin_versions.html', versions=versions)

@main_bp.route('/admin/revert/<int:version_id>', methods=['POST'])
@role_required('admin')
def admin_revert(version_id):
    v = OrderVersion.query.get_or_404(version_id)
    # snapshot should be JSON that can be used to update order
    data = json.loads(v.snapshot)
    if not v.order_id:
        return jsonify({"error":"no associated order id"}), 400
    order = Order.query.get(v.order_id)
    if not order:
        return jsonify({"error":"order not found"}), 404
    order.customer_name = data.get('customer_name', order.customer_name)
    order.internal_notes = data.get('internal_notes', order.internal_notes)
    # rebuild items: remove existing and add new
    order.items = []
    for it in data.get('items', []):
        order.items.append(OrderItem(
            material=it.get('material'),
            quantity=it.get('quantity'),
            unit=it.get('unit'),
            supplier=it.get('supplier'),
            payment_terms=it.get('payment_terms'),
            import_license=it.get('import_license'),
            notes=it.get('notes')
        ))
    db.session.commit()
    flash("Order reverted to selected version", "success")
    return redirect(url_for('main.admin_versions'))