# app/models.py - SQLAlchemy models including versioning and notifications
from . import db
from datetime import datetime
from flask_login import UserMixin

roles_users = db.Table('roles_users',
    db.Column('user_id', db.Integer, db.ForeignKey('user.id')),
    db.Column('role_id', db.Integer, db.ForeignKey('role.id'))
)

class Role(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), unique=True)

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, index=True, nullable=False)
    name = db.Column(db.String(120))
    password_hash = db.Column(db.String(128))
    # notification preferences JSON-like string (simple)
    notifications = db.Column(db.Text, default='{}')
    roles = db.relationship('Role', secondary=roles_users, backref=db.backref('users', lazy='dynamic'))

    def has_role(self, role_name):
        return any(r.name == role_name for r in self.roles)

class OrderItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    material = db.Column(db.String(256))
    quantity = db.Column(db.Float, default=0)
    unit = db.Column(db.String(64))
    supplier = db.Column(db.String(256))
    delivery_date = db.Column(db.DateTime, nullable=True)
    payment_terms = db.Column(db.String(256))
    import_license = db.Column(db.String(256))
    notes = db.Column(db.Text)
    order_id = db.Column(db.Integer, db.ForeignKey('order.id'))

class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    order_number = db.Column(db.String(128), unique=True, index=True)
    customer_name = db.Column(db.String(256))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    delivery_date = db.Column(db.DateTime, nullable=True)
    status = db.Column(db.String(64), default='draft')
    created_by_email = db.Column(db.String(120))
    items = db.relationship('OrderItem', backref='order', lazy=True, cascade="all, delete-orphan")
    # internal fields (prices, internal notes) - included but hidden from customers
    internal_notes = db.Column(db.Text)

class OrderVersion(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey('order.id'), nullable=True)
    user_email = db.Column(db.String(120))
    snapshot = db.Column(db.Text)  # JSON stringified snapshot of order form
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    order = db.relationship('Order')

class Draft(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_email = db.Column(db.String(120), index=True)
    content = db.Column(db.Text)  # JSON stringified
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class NotificationLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_email = db.Column(db.String(120))
    channel = db.Column(db.String(64))  # email / telegram
    notif_type = db.Column(db.String(128))
    payload = db.Column(db.Text)
    sent_at = db.Column(db.DateTime, default=datetime.utcnow)
    success = db.Column(db.Boolean, default=False)
    error = db.Column(db.Text)